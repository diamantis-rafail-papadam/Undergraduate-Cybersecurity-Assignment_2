#include <stdbool.h>

#define maxInput 100000 //input longer than 10^5 characters will be interpreted as 10^5 characters and the rest will be ingored

struct result {
    unsigned char* msg;
    unsigned char* key;
};

struct result* OTP(unsigned char* message, unsigned char* key, bool encrypt);
struct result* ceasarCipher(unsigned char* message, unsigned char* key, bool encrypt);
struct result* vigenereCipher(unsigned char* message, unsigned char* key, bool encrypt);
struct result* getInput(int cipher); //Asks for input and reads it according to the cipher. 1 is OTP, 2 is Ceasar, 3 is Vigenere.
unsigned char** generateVigenereMatrix(); //Generate's the 26x26 matrix needed for Vigenere's cipher
unsigned char* createVigenereKey(unsigned char* initialKey); //returns a key the same size as the message, used for Vigenere's cipher
unsigned char* convertToUpperCase(unsigned char* message); //used for non-case sensitive vigenere cipher
unsigned char* generateRandomKey(int size); //used for OTP
unsigned char* generateValidCharacters(); //generates valid characetrs [0-9A-Za-z]
int findValidCharacterPos(char ch); //finds position of a valid character in [0-9A-Za-z] array which is used for ceasar's cipher
unsigned char* validateMessage(unsigned char* message, bool vigenere); //filters the input and returns the valid message (only letters and digits)
bool isPrintable(unsigned char* message);
void printResult(struct result* enc, struct result* dec, int cipher);
void printHex(unsigned char* message); //prints message in hexadecimal form
//void printInfo(unsigned char* initialMsg, unsigned char* validMsg, struct result* encrypted, struct result* decrypted);
//void printResHex(struct result* res); 