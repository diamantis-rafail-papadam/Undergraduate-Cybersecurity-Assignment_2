#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include "simple_crypto.h"

unsigned char* validChars;
int msgSize; //updated in function "validateMessage()"

int main() {
    //initialize variables
    unsigned char *message, *key;
    struct result* encrypted, *decrypted;
    unsigned char* validMessage;
    validChars = generateValidCharacters(); 

    struct result* (*cipherFunction[])(unsigned char*, unsigned char*, bool) = {OTP, ceasarCipher, vigenereCipher};
    //int size = (int)sizeof(cipherFunction)/sizeof(cipherFunction[0]);
    
    //read input and run the cipher algorithms
    for(int i = 0; i < 3; i++) {
        struct result* input = getInput(i);
        validMessage = validateMessage(input->msg, i==2); //second parameter is only true for vigenere algorithm
        encrypted = (*cipherFunction[i])(validMessage, input->key, true); //encrypt
        decrypted = (*cipherFunction[i])(encrypted->msg, encrypted->key, false); //decrypt
        printResult(encrypted, decrypted, i);
    }
    return 0;
}

struct result* getInput(int cipher) {
    struct result* input = (struct result *)malloc(sizeof(struct result));
    int intKey;
    input->msg = (unsigned char *)malloc(maxInput*sizeof(char));
    input->key = (unsigned char *)malloc(maxInput*sizeof(char));
    if(cipher == 0) {
        printf("%s", "[OTP] input: ");
        fgets(input->msg, maxInput, stdin);
        input->msg[strlen(input->msg) - 1] = '\0';
    } else if(cipher == 1) {
        printf("%s", "[Caesars] input: ");
        fgets(input->msg, maxInput, stdin);
        input->msg[strlen(input->msg) - 1] = '\0';
        printf("%s", "[Caesars] key: ");
        scanf("%d", &intKey); 
        fgetc(stdin);
        input->key[0] = intKey%strlen(validChars);
        input->key[1] = '\0';
    } else {
        printf("%s", "[Vigenere] input: ");
        fgets(input->msg, maxInput, stdin);
        input->msg[strlen(input->msg) - 1] = '\0';
        printf("%s", "[Vigenere] key: ");
        fgets(input->key, maxInput, stdin);
        input->key[strlen(input->key) - 1] = '\0';
    }
    return input;
}

struct result* OTP(unsigned char* message, unsigned char* key, bool encrypt) {
    struct result* res = (struct result *)malloc(sizeof(struct result));
    res->msg = (unsigned char *)malloc(msgSize*sizeof(char));
    res->key = (unsigned char *)malloc(msgSize*sizeof(char));

    if(encrypt)
        res->key =  generateRandomKey(msgSize);
    else {
        res->key = key;
    }
    for(int i = 0; i < msgSize; i++)
        res->msg[i] = message[i] ^ res->key[i];

    return res;
}

struct result* ceasarCipher(unsigned char* message, unsigned char *key, bool encrypt) {
    struct result* res = (struct result *)malloc(sizeof(struct result));
    res->msg = (unsigned char *)malloc(msgSize*sizeof(char));
    res->key = (unsigned char*)malloc(sizeof(char));
    res->key = key;

    if(encrypt) {
        for(int i = 0; i < msgSize; i++) {
            int charPos = findValidCharacterPos(message[i]);
            if(charPos == -1) {
                printf("ERROR: Ceasar Cipher was given bad input!\n");
                return NULL;
            }
            res->msg[i] = validChars[(charPos + (int)key[0])%strlen(validChars)];
        }
    } else {
        for(int i = 0; i < msgSize; i++) {
            int charPos = findValidCharacterPos(message[i]);
            if(charPos == -1) {
                printf("ERROR: Ceasar Cipher was given bad input!\n");
                return NULL;
            }
            int finalPos, temp = charPos - (int)key[0]%strlen(validChars);
            if(temp >= 0)
                finalPos = temp;
            else
                finalPos = strlen(validChars) + temp;
            res->msg[i] = validChars[finalPos];
        }
    }
    
    return res;
}

struct result* vigenereCipher(unsigned char* message, unsigned char* key, bool encrypt) {
    struct result* res = (struct result *)malloc(sizeof(struct result));
    res->msg = (unsigned char *)malloc(msgSize*sizeof(char));
    res->key = (unsigned char *)malloc(msgSize*sizeof(char));
    unsigned char** vigenereMatrix = generateVigenereMatrix();

    if(encrypt) {
        unsigned char* normalizedMsg = convertToUpperCase(message);
        res->key = createVigenereKey(convertToUpperCase((key)));
        for(int i = 0; i < msgSize; i++)
            res->msg[i] = vigenereMatrix[(int)res->key[i] - 65][(int)normalizedMsg[i] - 65];
    } else {
        res->key = key;
        for(int i = 0; i < msgSize; i++) {
            int column = (int)message[i] - (int)res->key[i];
            if(column < 0)
                column = 26 + column;
            res->msg[i] = vigenereMatrix[0][column];
        }
    }

    return res;
}

unsigned char** generateVigenereMatrix() {
    unsigned char** vigenereMatrix = (unsigned char**)malloc(26*sizeof((unsigned char*)malloc(26*sizeof(char))));
    unsigned char* firstRow = (unsigned char*)malloc(26*sizeof(char));
    for(int i = 0; i < 26; i++) {
        firstRow[i] = (char)(i+65);
    }
    vigenereMatrix[0] = firstRow;
    for(int i = 1; i < 26; i++) {
        unsigned char* vigenereRow = (unsigned char*)malloc(26*sizeof(char));
        for(int j = 0; j < 26; j++)
            vigenereRow[j] = firstRow[(i+j)%26];
        vigenereMatrix[i] = vigenereRow;
    }
    //for(int i = 0; i < 26; i++) {
    //    printf("%s\n", vigenereMatrix[i]);
    //}
    return vigenereMatrix;
}

unsigned char* createVigenereKey(unsigned char* initialKey) {
    unsigned char* key = (unsigned char*)malloc(msgSize*sizeof(char));
    int sizeOfInitKey = strlen(initialKey);
    for(int i = 0; i < msgSize; i++) {
        key[i] = initialKey[i%sizeOfInitKey];
    }
    return key;
}

unsigned char* convertToUpperCase(unsigned char* message) {
    unsigned char* normalizedMessage = (unsigned char*)malloc(msgSize*sizeof(char));
    for(int i = 0; i < msgSize; i++)
        if((int)message[i] > 96)
            normalizedMessage[i] = message[i] - 32;
        else
            normalizedMessage[i] = message[i];
    return normalizedMessage;
}

unsigned char* generateRandomKey(int size) {
    unsigned char* key = (unsigned char*)malloc(size*sizeof(char));
    int f = open("/dev/urandom", O_RDONLY);
    read(f, key, size);
    close(f);
    return key;
}

unsigned char* generateValidCharacters() {
    int numOfValChars = 26 + 26 + 10; //26 lower-case & 26 upper-case letters as well as 10 digits.
    int digitStart = 48, upperCaseStart = 65, lowerCaseStart = 97, pos = 0;
    unsigned char* validChars = (unsigned char*)malloc(numOfValChars*sizeof(char));
    for(int i = digitStart; i < digitStart + 10; i++) {
        *(validChars + pos) = (char)i;
        pos++;
    }
    for(int i = upperCaseStart; i < upperCaseStart + 26; i++) {
        *(validChars + pos) = (char)i;
        pos++;
    }
    for(int i = lowerCaseStart; i < lowerCaseStart + 26; i++) {
        *(validChars + pos) = (char)i;
        pos++;
    }
    return validChars;
}

int findValidCharacterPos(char ch) {
    for(int i = 0; i < strlen(validChars); i++) {
        if(validChars[i] == ch)
            return i;
    }
    return -1;
}

unsigned char* validateMessage(unsigned char* message, bool vigenere) {
    unsigned char* validMessage = (unsigned char*)malloc((strlen(message) + 1)*sizeof(char));
    int pos = 0;
    for(unsigned char* it = message; *it != '\0'; it++) {
        if(isalpha(*it) || (!vigenere && isdigit(*it))) {
            *(validMessage + pos) = *it;
            pos++;
        }
    }
    *(validMessage+pos) = '\0';
    msgSize = strlen(validMessage);

    return validMessage;
}

bool isPrintable(unsigned char* message) {
    for(int i = 0; i < msgSize; i++) {
        if(isalpha(message[i]) || isdigit(message[i]))
            continue;
        else
            return false;
    }
    return true;
}

void printResult(struct result* enc, struct result* dec, int cipher){
    if(cipher == 0) {
        if(isPrintable(enc->msg))
            printf("[OTP] encrypted: %s\n", enc->msg);
        else {
            printf("[OTP] encrypted: ");
            printHex(enc->msg);
            printf(" (Hexadecimal)\n");
        }
        printf("[OTP] decrypted: %s\n", dec->msg);
    }
    else if(cipher ==1)
        printf("[Caesars] encrypted: %s\n[Caesars] decrypted: %s\n", enc->msg, dec->msg);
    else if(cipher == 2)
        printf("[Vigenere] encrypted: %s\n[Vigenere] decrypted: %s\n", enc->msg, dec->msg);
}

void printHex(unsigned char* message) {
    for(int i = 0; i < msgSize; i++)
        printf("%02x", *(message + i));
}

/*
void printInfo(unsigned char* initialMsg, unsigned char* validMsg, struct result* encrypted, struct result* decrypted) {
    printf("Initial message to be sent: %s\n", initialMsg);
    printf("Valid message to be sent: %s\n", validMsg);
    printf("Randomly generated key in hexadecimal: ");
    printHex(encrypted->key);
    if(isPrintable(encrypted->msg))
        printf("Message after encryption: %s\n", encrypted->msg);
    else {
        printf("Message after encryption in hexadecimal: ");
        printHex(encrypted->msg);
    }
    printf("Message after decryption with the same key: %s\n", decrypted->msg);
}

void printResHex(struct result* res) {
    printf("Key: ");
    for(int i = 0; i < msgSize; i++)
        printf("%02x", *(res->key + i));
    printf("\nNew Message: ");
    for(int i = 0; i < msgSize; i++)
        printf("%02x", *(res->msg + i));
    printf("\n");
}
*/